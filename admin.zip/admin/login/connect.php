<?php 
$connect = mysqli_connect('localhost', 'root', 'root', 'cataloq');

?>